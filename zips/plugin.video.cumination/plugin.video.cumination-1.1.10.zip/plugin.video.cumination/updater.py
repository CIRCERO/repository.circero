import requests
import hashlib
from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
from six import PY2
import time
import os
TRANSLATEPATH = xbmc.translatePath if PY2 else xbmcvfs.translatePath
addon_id            = 'plugin.video.cumination'
AddonTitle          = '[COLOR yellow][B]cumination Aio[/B][/COLOR]'
Addonicon           = TRANSLATEPATH(os.path.join('special://home/media/' + 'images', 'icon.gif'))
dialog              = xbmcgui.Dialog()
def Check(check):
	file1 = TRANSLATEPATH(os.path.join('special://home/addons/', 'plugin.video.cumination/%s' % check.lower()))
	file1check = open(file1).read()
	file2 = requests.get('https://raw.githubusercontent.com/circero/repository.circero/master/zips/plugin.video.cumination/%s' % check).content
	check1 = hashlib.md5(file1check).hexdigest()
	check2 = hashlib.md5(file2).hexdigest()
	if check1 == check2:
		pass
	else:
		with open (file1, 'w') as F:
			F.write(file2)
			dialog.notification(AddonTitle, '[COLOR yellow]Updated %s Addon[/COLOR]' %check, Addonicon, 2500)
			time.sleep(1)
			