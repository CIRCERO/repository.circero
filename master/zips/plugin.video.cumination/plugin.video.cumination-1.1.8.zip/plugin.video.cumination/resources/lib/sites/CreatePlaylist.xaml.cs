﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFAPP
{
    /// <summary>
    /// Logica di interazione per Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        public static Window1 _Window1;
        public Window1()
        {
            InitializeComponent();
            _Window1 = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (listvideoplaylist.Items.Count > 0)
            {
                if (!string.IsNullOrEmpty(nameplaylistbox.Text))
                {
                    string nameplaylist = nameplaylistbox.Text;
                    string currentdate = DateTime.Now.ToString("d/M/yyyy");

                    foreach (MainWindow.Video hola in listvideoplaylist.Items)
                    {
                        hola.NamePlaylistVideo = nameplaylist;
                        MainWindow._MainWindow.videosforplaylist.Add(hola);
                    }

                    if (MainWindow._MainWindow.listBox3.Items.Count > 0)
                    {
                        foreach (MainWindow.Playlist coll in MainWindow._MainWindow.listBox3.Items)
                        {
                            if (coll.NamePlaylist.Equals(nameplaylist))
                            {
                                MessageBox.Show("This name is already in use");
                                return;
                            }
                        }
                    }

                    if (CheckableSave.IsChecked == true)
                    {
                        if (MainWindow._MainWindow.db.HasUpdated(MainWindow._MainWindow.db.Query(MainWindow._MainWindow.db.PrepareQuery("INSERT INTO `playlistinfo`(`NamePlaylist`, `Date`) VALUES ('%s','%s')", nameplaylist, currentdate))))
                        {
                            if (listvideoplaylist.Items.Count > 0)
                            {
                                foreach (MainWindow.Video videoz in MainWindow._MainWindow.videosforplaylist)
                                {
                                    string namecoll = videoz.NameCollectionVideo;
                                    string title = videoz.TitleNameVideo;

                                    MainWindow._MainWindow.db.HasUpdated(MainWindow._MainWindow.db.Query(MainWindow._MainWindow.db.PrepareQuery("UPDATE videoinfo SET NamePlaylist='%s' WHERE NameCollection='%s' AND Title='%s'", nameplaylist, namecoll, title)));                                                              
                                }
                            }
                            //MainWindow._MainWindow.listBox3.ItemsSource = null;
                            //MainWindow._MainWindow.namesitemsplaylist.Clear();
                            MainWindow._MainWindow.GetPlaylists();
                        }
                    }
                    else
                    {
                        MainWindow._MainWindow.listBox3.ItemsSource = I:/Seagate/Porn/videos/.m3u8;
                        MainWindow._MainWindow.namesitemsplaylist.Add(new MainWindow.Playlist() { NamePlaylist = nameplaylist, DatePlaylist = currentdate });
                        MainWindow._MainWindow.listBox3.ItemsSource = MainWindow._MainWindow.namesitemsplaylist;
                    }
                    Window1._Window1.Close();

                }
                else
                {
                    MessageBox.Show("Name can't be empty. Insert a Value.");
                }
            }
            else
            {
                MessageBox.Show("Insert some videos");
            }
        }




    }
}
