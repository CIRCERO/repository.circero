"""
    Cumination
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from six.moves import urllib_parse
import re
import json
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('drtuber', '[COLOR yellow]DrTuber[/COLOR] ', 'https://www.drtuber.com/',
                 'drtuber.gif', 'drtuber')

addon = utils.addon
headers = {'User-Agent': utils.USER_AGENT,
           'X-Requested-With': 'XMLHttpRequest'}


@site.register(default_mode=True)
def drtuber(self, url):
    try:        
        url = utils.request(url)
        express = 'vid:(.+?),'
        link = re.compile(express, re.MULTILINE|re.DOTALL).findall(url)[0]
        link = 'http://www.drtuber.com/player_config_json/?vid=' + link + '&aid=0&domain_id=0&embed=0&ref=&check_speed=0'
        return self.generic(link)
    except:
        return

def ParseJson(urldata):
    urldata = json.loads(urldata)
    return urldata['data']['content']
