﻿using System;
using System.Windows;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WPFAPP
{
    class Configuration
    {
        public static string xmlPath = "C:\\Users\\" + Environment.UserName + "\\Documents\\PlayListApp\\Config.xml";
        public XmlSerializer ser = new XmlSerializer(typeof(Conf));
        public Configuration()
        {
        }

        public void SaveFile(String Host,String User,String Pass, String DB)
        {
            string xmldir="C:\\Users\\" + Environment.UserName + "\\Documents\\PlayListApp";
            try
            {
                if (!Directory.Exists(xmldir))
                {
                    Directory.CreateDirectory(xmldir);
                }
                Conf cfg = new Conf();
                cfg.HOST = Host;
                cfg.USER = User;
                cfg.PASS = Pass;
                cfg.DBNAME = DB;
                TextWriter writer = new StreamWriter(xmlPath);
                ser.Serialize(writer, cfg);
                writer.Close();
            }
            catch(Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }
        }

        public Conf ReadFile()
        {
            TextReader reader = new StreamReader(xmlPath);
            object obj = ser.Deserialize(reader);
            Conf cfg = new Conf();
            cfg=(Conf)obj;
            reader.Close();
            return cfg;
        }
    }

    public class Conf
    {
        public String HOST { get; set; }
        public String USER { get; set; }
        public String PASS { get; set; }
        public String DBNAME { get; set; }
       public Conf()
        {

        }
    }
}
