﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Net;

namespace WPFAPP
{
    /// <summary>
    /// Logica di interazione per InfoWindow.xaml
    /// </summary>
    public partial class InfoWindow : Window
    {
        public static InfoWindow _infowin;
        public InfoWindow()
        {
            InitializeComponent();
            _infowin = this;
            dwnloadbtn.IsEnabled = false;
            infov.Text += " " + System.Reflection.Assembly.GetEntryAssembly().GetName().Version.ToString() + " MediaPlaylister";
        }

        public void Download(Uri url, string folder)
        {
            using (WebClient webclient = new WebClient())
            {
                webclient.DownloadFileCompleted += new System.ComponentModel.AsyncCompletedEventHandler(Completed);

                try
                {
                    webclient.DownloadFileAsync(url, folder);
                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message); }
            }
        }
        private void Completed(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            Process.Start(new ProcessStartInfo()
            {
                FileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\PlaylisterUpdater.exe",
            });
            Process.Start(new ProcessStartInfo()
            {
                Arguments = "/C choice /C Y /N /D Y /T 3 & Del \"" + System.Reflection.Assembly.GetExecutingAssembly().Location + "\"",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                FileName = "cmd.exe"
            });
            Application.Current.Shutdown();
        }

        private void dwnloadbtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Are you sure to update current version of software? If you click 'Yes' you will download new version. Updater automatically delete your last one.", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    Download(new Uri(MainWindow._MainWindow.downloadupdater), System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\PlaylisterUpdater.exe");

                }
                catch(Exception ex)
                {
                        MessageBox.Show(ex.Message);
                }          
            }     
        }
    }
}
