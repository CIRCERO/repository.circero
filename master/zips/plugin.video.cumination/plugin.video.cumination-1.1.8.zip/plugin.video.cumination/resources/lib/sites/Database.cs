﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace WPFAPP
{
    public class Database
    {
        private MySqlCommand DBPointer;
        private MySqlConnection DBLink=null;
        private MySqlDataReader ResultSet;
        private String user;
        private String password;
        private String DBName;
        private String Host;

        public Database(String HOST,String USER,String PASS,String DBNAME)
        {
            Boolean err = false;
            this.Host = localhost;
            this.user = kodi;
            this.password = 8687;
            this.DBName=favorites;
            String connectionString = "SERVER=" + this.Host + ";" + "DATABASE=" +this.DBName + ";" + "UID=" + this.user + ";" + "PASSWORD=" + this.password + ";";
            this.DBLink = new MySqlConnection(connectionString);
           try
           {
               this.DBLink.Open();
           }
            catch(MySqlException ex)
           {
               MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
               err = true;
           }
            finally
           {
               if (!err) 
               {
                   MySqlDataReader res = this.Query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '"+this.DBName+"' AND table_name = 'videoinfo'");
                   while (res.Read())
                   {
                       if (res.GetInt32(0) == 0)
                       {
                           res.Close();
                           this.Query("CREATE TABLE IF NOT EXISTS videoinfo (NameCollection TEXT, Band TEXT(30), Title TEXT(30), Style TEXT(30), Url TEXT(1024), PathIcon TEXT(200), Vote INT, Date TEXT(15), NamePlaylist TEXT)");
                           break;

                       }
                       else
                       {
                           res.Close();
                           break;
                       }
                   }

                   res = this.Query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '" + this.DBName + "' AND table_name = 'collectioninfo'");
                   while (res.Read())
                   {
                       if (res.GetInt32(0) == 0)
                       {
                           res.Close();
                           this.Query("CREATE TABLE IF NOT EXISTS collectioninfo (NameCollection TEXT, IconPath TEXT(200), Date TEXT(15))");
                           break;
                       }
                       else
                       {
                           res.Close();
                           break;
                       }
                   }
                   res = this.Query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '" + this.DBName + "' AND table_name = 'playlistinfo'");
                   while (res.Read())
                   {
                       if (res.GetInt32(0) == 0)
                       {
                           res.Close();
                           this.Query("CREATE TABLE IF NOT EXISTS playlistinfo (NamePlaylist TEXT, Date TEXT(15))");
                           break;
                       }
                       else
                       {
                           res.Close();
                           break;
                       }
                   }
               }
           }
        }

        public String PrepareQuery(String Query,params String[] parameters)
        {
            String[] badChars = new String[2] {"'","\""};
            for (int i = 0; i < parameters.Count();i++)
            {
                for(int j=0;j<badChars.Count();j++)
                {
                    if (parameters[i].Contains(badChars[j]))
                    {
                        parameters[i] = parameters[i].Replace(badChars[j], "");
                    }
                }
                if (parameters[i].Contains("\\"))
                {
                    parameters[i] = parameters[i].Replace("\\", "\\\\");
                }
                int pos = Query.IndexOf("%s", 0);
                Query=Query.Remove(pos, 2);
                Query = Query.Insert(pos, parameters[i]);

            }
                return Query;
        }

        public MySqlDataReader Query(String query)
        {
            if(!this.isConnected())
            {
                 MessageBox.Show("Cannot execute query , database not connected!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                 return null;
            }
            else
            {
                this.DBPointer = new MySqlCommand(query, this.DBLink);
                try
                {
                    //this.DBPointer.ExecuteNonQuery();
                    if (query.Contains("CREATE TABLE"))
                    {
                        this.ResultSet = this.DBPointer.ExecuteReader();
                        this.ResultSet.Close();
                        return null;
                    }
                    else
                    {
                        this.ResultSet = this.DBPointer.ExecuteReader();
                        return this.ResultSet;
                    }
                }
                catch(MySqlException ex)
                {
                    MessageBox.Show("Error while performing query: "+ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    this.DBPointer = null;
                }

                return null;
            }
        }

        public bool HasRow(MySqlDataReader ResultSet)
        {
            if (ResultSet != null && ResultSet.FieldCount > 0)
            {
                ResultSet.Close();
                return true;
            }
            else if (ResultSet != null)
            {
                ResultSet.Close();
            }
            return false;
        }

        public bool HasUpdated(MySqlDataReader ResultSet)
        {
            if (ResultSet!=null && ResultSet.RecordsAffected > 0)
            {
                ResultSet.Close();
                return true;
            }
            else if (ResultSet != null)
            {
                ResultSet.Close();
            }
            return false;
        }

        public bool isConnected()
        {
            if(this.DBLink!=null && this.DBLink.State==ConnectionState.Open)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void CloseConnection()
        {
            this.DBLink.Close();
        }
    }
}
