﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WPFAPP
{
    public partial class VlcFound : UserControl
    {
        public static VlcFound _VlcFound;
        public VlcFound()
        {
            InitializeComponent();
            _VlcFound = this;
        }

        private void axVLCPlugin21_Enter(object sender, EventArgs e)
        {

        }

        private void axVLCPlugin21_MediaPlayerPlaying(object sender, EventArgs e)
        {
            if (MainWindow._MainWindow.PositionChanged == true)
            {
                axVLCPlugin21.input.Position = MainWindow._MainWindow.PositionNewValue;
            }
            MainWindow._MainWindow.SliderTime.IsEnabled = true;
            MainWindow._MainWindow.textblock1.Text = TimeFormat((int)axVLCPlugin21.input.Length);
            MainWindow._MainWindow.ValueMaxProg = (int)axVLCPlugin21.input.Length;
            //MainWindow._MainWindow.SliderTime.Maximum = 100;
            //MainWindow._MainWindow.SliderTime.Minimum = 0;
            MainWindow._MainWindow.CurrentSeconds = 1;
            MainWindow._MainWindow.timer.Interval = TimeSpan.FromSeconds(1);
            MainWindow._MainWindow.timer.Tick += timer_tick;
            MainWindow._MainWindow.timer.Start();
        }
        public static string TimeFormat(int milliseconds)
        {
            int itotalseconds = milliseconds / 1000;
            int hours = itotalseconds / 3600;
            int hours_res = itotalseconds - (hours * 3600);
            int minuts = hours_res / 60;
            int minuts_res = hours_res - (minuts * 60);
            int seconds = minuts_res % 60;
            string strTimetostring = string.Format("{0,1}:{1,2:D2}:{2,2:D2}", hours, minuts, seconds);
            return strTimetostring;
        }
        public static void timer_tick(object sender, EventArgs e)
        {
            if (MainWindow._MainWindow.ValueMaxProg != 0)
            {
                //MainWindow._MainWindow.textblock1.Text = ((MainWindow._MainWindow.CurrentSeconds / 1000)).ToString();
                int Valuebar = (100 * ((MainWindow._MainWindow.CurrentSeconds / 1000))) / (MainWindow._MainWindow.ValueMaxProg / 1000);
                MainWindow._MainWindow.SliderTime.Value = Valuebar;
            }
        }
        private void axVLCPlugin21_MediaPlayerTimeChanged(object sender, AxAXVLC.DVLCEvents_MediaPlayerTimeChangedEvent e)
        {
            MainWindow._MainWindow.PositionNewValue = axVLCPlugin21.input.Position;
            MainWindow._MainWindow.textblock2.Text = TimeFormat(e.time);
            if(!MainWindow._MainWindow.Slider.IsEnabled == false)
            {
                axVLCPlugin21.Volume = MainWindow._MainWindow.SavedCurrentVolume;
                axVLCPlugin21.audio.Volume = MainWindow._MainWindow.SavedCurrentVolume;
            }
            else
            {
                axVLCPlugin21.Volume = 0;
                axVLCPlugin21.audio.Volume = 0;
            }
            MainWindow._MainWindow.CurrentSeconds = (int)axVLCPlugin21.input.Time;
        }

        private void axVLCPlugin21_MediaPlayerStopped(object sender, EventArgs e)
        {
            MainWindow._MainWindow.timer.Stop();
            MainWindow._MainWindow.SliderTime.Value = 0;
            MainWindow._MainWindow.textblock1.Text = "0:00:00";
            MainWindow._MainWindow.textblock2.Text = string.Empty;
        }
    }
}
