﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Xml.Linq;
using System.Xml.XPath;
using System.ComponentModel;
using System.Data;
using MyToolkit.Multimedia;
using MyToolkit.Utilities;
using MyToolkit.UI;
using AxAXVLC;
using AXVLC;
using System.IO;
using System.Threading;
using System.Net;
using System.Diagnostics;



namespace WPFAPP
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow _MainWindow;
        public static RoutedCommand DeleteCollection = new RoutedCommand();
        public static RoutedCommand ResetCollection = new RoutedCommand();
        public static RoutedCommand ResetPlaylists = new RoutedCommand();
        public static RoutedCommand DeleteVideo = new RoutedCommand();
        public static RoutedCommand ResetVideo = new RoutedCommand();
        public static RoutedCommand ResetConfiguration = new RoutedCommand();
        public static RoutedCommand SearchItem = new RoutedCommand();
        public static RoutedCommand ChangeIcon = new RoutedCommand();
        public static RoutedCommand ChangeName = new RoutedCommand();
        public static RoutedCommand DeletePlaylist = new RoutedCommand();

        public Database db;
        public List<Collection> namesitemscollections = new List<Collection>();
        public List<Video> namesitemsvideos = new List<Video>();
        public List<Video> videosforplaylist = new List<Video>();
        public List<Playlist> namesitemsplaylist = new List<Playlist>();
        public static System.Windows.Forms.WebBrowser webBrowser1 = new System.Windows.Forms.WebBrowser() { Url = new Uri("http://napolisourceproject.altervista.org/Version.html") };

        public System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        public VlcFound vlcfound = new VlcFound();

        int curRate = 0;
        Object[] elem = new Object[5];

        public int SavedCurrentVolume { get; set; } 
        public string iconpathcollection { get; set; }
        public string iconpathvideo { get; set; }
        public int numbercollections { get; set; }
        public int numbervideos { get; set; }
        public string urltoplay { get; set; }
        public int ValueMaxProg { get; set; }
        public int CurrentSeconds { get; set; }
        public bool PositionChanged { get; set; }
        public double PositionNewValue { get; set; }
        public bool btnenabled { get; set; }
        public string downloadupdater { get; set; }

        public static string xml = @"C:\Users\" + Environment.UserName + "\\Documents\\PlayListApp\\Config.xml";
        public static string curversion = System.Reflection.Assembly.GetEntryAssembly().GetName().Version.ToString();


        public class Collection
        {
            public string Namecollection { get; set; }
            public string IconPathcollection { get; set; }
            public string DateCollec { get; set; }
        }
        public class Playlist
        {
            public string NamePlaylist { get; set; }
            public string DatePlaylist { get; set; }
        }
        public class Video
        {
            public string NameCollectionVideo { get; set; }
            public string NamePlaylistVideo { get; set; }
            public string BandNameVideo { get; set; }
            public string TitleNameVideo { get; set; }
            public string StyleNameVideo { get; set; }
            public string UrlVideo { get; set; }
            public string IconPathvideo { get; set; }
            public string DateVideo { get; set; }
            public string VoteVideo { get; set; }
        }




        //Se non utilizzo hasrow o hasupdated chiudere con "reader.close".
        public MainWindow()
        {
            InitializeComponent();
            _MainWindow = this;
            boxPath.Text = @"C:\Users\" + Environment.UserName + "\\Documents\\PlayListApp";
            SliderTime.IsEnabled = false;
            if (File.Exists(Configuration.xmlPath))
            {
                Configuration xml = new Configuration();
                Conf DBConf = xml.ReadFile();
                serverBox.Text = DBConf.HOST;
                roousBox.Text = DBConf.USER;
                roopwBox.Text = DBConf.PASS;
                databaseBox.Text = DBConf.DBNAME;
                db = new Database(DBConf.HOST, DBConf.USER, DBConf.PASS, DBConf.DBNAME);
                GetCollections();
                GetPlaylists();
            }
            else
            {
                serverBox.Text = "Insert server name";
                roousBox.Text = "Insert root username";
                roopwBox.Text = "Insert root password";
                databaseBox.Text = "Insert database name";
            }

            SavedCurrentVolume = 10;
            Slider.Value = SavedCurrentVolume;
            WindowsFormsHost.Child = vlcfound;
           
            host2.Child = webBrowser1;
            CounterLabel.Content = "Collections: " + numbercollections + "  " + "Videos: " + numbervideos;
            textblock1.Text = "0:00:00";
            PositionNewValue = 0;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int j = 0;
            for (int i = 0; i < DetailGrid.Children.Count; i++)
            {
                if (this.DetailGrid.Children[i].GetType() == typeof(Image))
                {
                    elem[j] = (Image)this.DetailGrid.Children[i];
                    j++;
                }
            }
            labelversion.Content = "Version " + curversion;

        }
        public void CheckVersion()
        {
            if (!string.IsNullOrEmpty(curversion))
            {
                try
                {
                    string newversion = webBrowser1.Document.GetElementById("version").GetAttribute("value");
                    string downloadurl = webBrowser1.Document.GetElementById("downloadurl").GetAttribute("value");
                    downloadupdater = webBrowser1.Document.GetElementById("updater").GetAttribute("value");
                    if (curversion != newversion && !string.IsNullOrEmpty(downloadurl) && !string.IsNullOrEmpty(downloadupdater))
                    {
                        dispversion.Foreground = Brushes.ForestGreen;
                        dispversion.Content = "Disponible version " + newversion+"!";
                        btnenabled = true;           
                    }
                    else
                    {
                        dispversion.Foreground = Brushes.LightSlateGray;
                        dispversion.Content = "Application already updated";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cant connect to server");
                }
            }
        }
        public void ExecuteBackupNow()
        {           
            string bckupfolder = "C:\\Users\\" + Environment.UserName + "\\Documents\\PlayListApp\\Backups";
            string backupfile = bckupfolder + "\\backup.sql";

            if (db != null && db.isConnected())
            {
                MessageBoxResult result = MessageBox.Show("Do you want make a backup of current database?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    if (!Directory.Exists(bckupfolder))
                    {
                        Directory.CreateDirectory(bckupfolder);
                    }

                    if (File.Exists(Configuration.xmlPath))
                    {
                        Configuration xml = new Configuration();
                        Conf DBConf = xml.ReadFile();
                        string constring = "server=" + DBConf.HOST + ";" + "user=" + DBConf.USER + ";" + "pwd=" + DBConf.PASS + ";" + "database=" + DBConf.DBNAME + ";";
                        using (MySqlConnection conn = new MySqlConnection(constring))
                        {
                            using (MySqlCommand cmd = new MySqlCommand())
                            {
                                using (MySqlBackup mb = new MySqlBackup(cmd))
                                {
                                    cmd.Connection = conn;
                                    conn.Open();
                                    mb.ExportToFile(backupfile);
                                    conn.Close();
                                    MessageBox.Show("Backup completed");
                                }
                            }
                        }
                    }
                }
            }
        }
        public void ExecuteRestoreNow()
        {
            if (db != null && db.isConnected())
            {
                MessageBoxResult result = MessageBox.Show("Do you want make a restore of database?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        Configuration xml = new Configuration();
                        Conf DBConf = xml.ReadFile();
                        string constring = "server=" + DBConf.HOST + ";" + "user=" + DBConf.USER + ";" + "pwd=" + DBConf.PASS + ";" + "database=" + DBConf.DBNAME + ";";

                        OpenFileDialog ofd = new OpenFileDialog();
                        ofd.Filter = "Sql backup(*.sql)|*.sql";
                        if (ofd.ShowDialog() == true)
                        {
                            using (MySqlConnection conn = new MySqlConnection(constring))
                            {
                                using (MySqlCommand cmd = new MySqlCommand())
                                {
                                    using (MySqlBackup mb = new MySqlBackup(cmd))
                                    {
                                        cmd.Connection = conn;
                                        conn.Open();
                                        mb.ImportFromFile(ofd.FileName);
                                        conn.Close();
                                        MessageBox.Show("Restore completed");
                                        listBox1.ItemsSource = null;
                                        namesitemscollections.Clear();
                                        GetCollections();
                                        listBox2.ItemsSource = null;
                                        namesitemsvideos.Clear();
                                        GetVideos();
                                    }
                                }
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
        public void GetCollections()
        {
           if(db.isConnected())
           {
               if (db.HasRow(db.Query("select * from collectioninfo"))) //controlli se ci sono collection
               {
                   MySqlDataReader resultset = db.Query("select NameCollection, IconPath, Date from collectioninfo"); // se ci sono le cicli e le aggiungi else non devi aggiungere niente asp devi richiamare
                   while (resultset.HasRows)
                   {
                       while (resultset.Read())
                       {
                           listBox1.ItemsSource = null;
                           namesitemscollections.Add(new Collection() {Namecollection = resultset.GetString(0), IconPathcollection = resultset.GetString(1),
                           DateCollec = resultset.GetString(2) }); 
                       }
                       resultset.NextResult();
                   }
                   listBox1.ItemsSource = namesitemscollections;
                   numbercollections = namesitemscollections.Count;
                   resultset.Close();
               }
           }
        }
        public void GetPlaylists()
        {
            if (db.isConnected())
            {
                if (db.HasRow(db.Query("select * from playlistinfo"))) //controlli se ci sono collection
                {

                    MySqlDataReader resultset = db.Query("select NamePlaylist, Date from playlistinfo"); // se ci sono le cicli e le aggiungi else non devi aggiungere niente asp devi richiamare
                    while (resultset.HasRows)
                    {
                        while (resultset.Read())
                        {
                            listBox3.ItemsSource = null;
                            namesitemsplaylist.Add(new Playlist(){NamePlaylist = resultset.GetString(0), DatePlaylist=resultset.GetString(1)});                         
                         }
                        resultset.NextResult();
                    }

                    var myDistinctList = namesitemsplaylist.GroupBy(i => i.NamePlaylist)
                     .Select(g => g.First()).ToList();
                    namesitemsplaylist = myDistinctList;


                    listBox3.ItemsSource = namesitemsplaylist;
                    numbervideos = namesitemsvideos.Count;
                    CounterLabel.Content = "Collections: " + numbercollections + "  " + "Videos: " + numbervideos;
                    resultset.Close();
                }
            }
        }
        
        public void GetVideos()
        {
            if (listBox1.Items.Count > 0 && listBox1.SelectedIndex > -1)
            {
                listBox2.ItemsSource = null;
                namesitemsvideos.Clear();
                String item = (listBox1.SelectedItem as Collection).Namecollection;
                MySqlDataReader res = db.Query(db.PrepareQuery("select Band, Title, Style, PathIcon, Url, Vote, Date, NameCollection from videoinfo where NameCollection='%s'", item));
                while (res.HasRows)
                {
                    while (res.Read())
                    {
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Add(new Video() 
                        { BandNameVideo = res.GetString(0), TitleNameVideo = res.GetString(1), StyleNameVideo = res.GetString(2),
                            IconPathvideo = res.GetString(3), UrlVideo = res.GetString(4), VoteVideo = res.GetString(5),DateVideo = res.GetString(6), NameCollectionVideo = res.GetString(7)});                     
                    }
                    res.NextResult();
                }
                listBox2.ItemsSource = namesitemsvideos;
                numbervideos = namesitemsvideos.Count;
                CounterLabel.Content = "Collections: " + numbercollections + "  " + "Videos: " + numbervideos;

                res.Close();
            }
        }
        public void GetVideosPlaylist()
        {
            if (listBox3.Items.Count > 0 && listBox3.SelectedIndex > -1)
            {
                bool itexists = false;
                MySqlDataReader res;
                String item = (listBox3.SelectedItem as Playlist).NamePlaylist;
                res = db.Query(db.PrepareQuery("SELECT COUNT(*) FROM playlistinfo where NamePlaylist='%s'", item));
                
                    while (res.Read())
                    {
                        if (res.GetInt32(0) == 1)
                        {
                            res.Close();
                            itexists = true;
                            break;
                        }
                    }
                    res.Close();
                

                if (itexists == true)
                {
                    listBox2.ItemsSource = null;
                    namesitemsvideos.Clear();

                    res = db.Query(db.PrepareQuery("select Band, Title, Style, PathIcon, Url, Vote, Date, NameCollection from videoinfo where NamePlaylist='%s'", item));
                    while (res.HasRows)
                    {
                        while (res.Read())
                        {
                            listBox2.ItemsSource = null;
                            namesitemsvideos.Add(new Video()
                            {
                                BandNameVideo = res.GetString(0),
                                TitleNameVideo = res.GetString(1),
                                StyleNameVideo = res.GetString(2),
                                IconPathvideo = res.GetString(3),
                                UrlVideo = res.GetString(4),
                                VoteVideo = res.GetString(5),
                                DateVideo = res.GetString(6),
                                NameCollectionVideo = res.GetString(7)
                            });
                        }
                        res.NextResult();
                    }
                    listBox2.ItemsSource = namesitemsvideos;
                    numbervideos = namesitemsvideos.Count;
                    CounterLabel.Content = "Collections: " + numbercollections + "  " + "Videos: " + numbervideos;

                    res.Close();
                }
                else if (itexists == false)
                {
                    List<Video> xxxxaa = new List<Video>();
                    foreach (Video x in videosforplaylist )
                    {
                        if(x.NamePlaylistVideo.Equals(item))
                        {
                            xxxxaa.Add(x);
                        }
                    }
                    listBox2.ItemsSource = null;
                    listBox2.ItemsSource = xxxxaa;
                }

            }
            
        }
        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CancelDetails();
            GetVideos();
        }
        public void CreateCollections()
        {
            string currentdate = DateTime.Now.ToString("d/M/yyyy");
            string name = boxCollection.Text;
            if (string.IsNullOrEmpty(iconpathcollection))
            {
                if(listBox1.Items.Count > 0)
                {
                    foreach(Collection coll in listBox1.Items)
                    {
                        if (coll.Namecollection.Equals(name))
                        {
                            MessageBox.Show("This name is already in use");
                            return;
                        }
                    }
                }
                if (db.HasUpdated(db.Query(db.PrepareQuery("INSERT INTO `collectioninfo`(`NameCollection`,`IconPath`, `Date`) VALUES ('%s','%s', '%s')", name, "NULL", currentdate))))
                {
                    listBox1.ItemsSource = null;
                    iconpathcollection = null;
                    namesitemscollections.Clear();
                    GetCollections();
                }
            }
            else
            {
                MessageBox.Show(currentdate);
                if (listBox1.Items.Count > 0)
                {
                    foreach (Collection coll in listBox1.Items)
                    {
                        if (coll.Namecollection.Equals(name))
                        {
                            MessageBox.Show("This name is already in use");
                            return;
                        }
                    }
                }
                if (db.HasUpdated(db.Query(db.PrepareQuery("INSERT INTO `collectioninfo`(`NameCollection`,`IconPath`,`Date`) VALUES ('%s','%s','%s')", name, iconpathcollection, currentdate))))
                {
                    listBox1.ItemsSource = null;
                    iconpathcollection = null;
                    namesitemscollections.Clear();
                    GetCollections();
                }
            }
        }

        public void CreateVideo()
        {
            string currentdate = DateTime.Now.ToString("d/M/yyyy");
            string NameCollection = (listBox1.SelectedItem as Collection).Namecollection;
            string Band = boxVideo1.Text;
            string Title = boxVideo2.Text;
            string Style = boxVideo3.Text;
            string Url = boxVideo5.Text;
            if (string.IsNullOrEmpty(iconpathvideo))
            {
                if (listBox2.Items.Count > 0)
                {
                    foreach (Video video in listBox2.Items)
                    {
                        if (video.TitleNameVideo.Equals(Title))
                        {
                            MessageBox.Show("This song already exists");
                            return;
                        }
                    }
                }
                if (db.HasUpdated(db.Query(db.PrepareQuery("INSERT INTO `videoinfo`(`NameCollection`, `Band`, `Title`, `Style`, `Url`, `PathIcon`, `Vote`, `Date`, `NamePlaylist`) VALUES ('%s','%s','%s','%s', '%s', '%s', %s, '%s', '%s')", NameCollection, Band, Title, Style, Url, "NULL", "1", currentdate, "NULL"))))
                {
                    listBox2.ItemsSource = null;
                    iconpathvideo = null;
                    namesitemsvideos.Clear();
                    GetVideos();
                }
            }
            else
            {
                if (listBox2.Items.Count > 0)
                {
                    foreach (Video video in listBox2.Items)
                    {
                        if (video.TitleNameVideo.Equals(Title))
                        {
                            MessageBox.Show("This song already exists");
                            return;
                        }
                    }
                }
                if (db.HasUpdated(db.Query(db.PrepareQuery("INSERT INTO `videoinfo`(`NameCollection`, `Band`, `Title`, `Style`, `Url`, `PathIcon`, `Vote`, `Date`, `NamePlaylist`) VALUES ('%s','%s','%s','%s','%s','%s','%s', '%s', '%s')", NameCollection, Band, Title, Style, Url, iconpathvideo, "0", currentdate, "NULL"))))
                {
                    listBox2.ItemsSource = null;
                    iconpathvideo = null;
                    namesitemsvideos.Clear();
                    GetVideos();
                }
            }
        }
        public void UpdateVideo()
        {
            if(listBox2.SelectedIndex > -1)
            {
                string band = (listBox2.SelectedItem as Video).BandNameVideo;
                string title = (listBox2.SelectedItem as Video).TitleNameVideo;
                string var1 = DetNameAlbum.Text;
                string var2 = DetNameSong.Text;
                string var3 = DetNameStyle.Text;
                string var4 = DetUrl.Text;
                string var5 = DetPathIcon.Text;
                string var6 = curRate.ToString();

                MessageBoxResult result = MessageBox.Show("Are you sure to update current video informations?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    if (db.HasUpdated(db.Query(db.PrepareQuery("UPDATE videoinfo SET Band='%s', Title='%s', Style='%s', Url='%s', PathIcon='%s', Vote='%s' WHERE Band='%s' AND Title='%s'", var1, var2, var3, var4, var5, var6, band, title))))
                    {
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Clear();
                        GetVideos();
                    }
                }
                curRate = 0;
            }
        }
        private void NewCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void RemoveCollection_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                try
                {
                    string item = (listBox1.SelectedItem as Collection).Namecollection;
                    MessageBoxResult result = MessageBox.Show("Do you want delete selected collection and all related videos?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        if (db.HasUpdated(db.Query(db.PrepareQuery("DELETE FROM `collectioninfo` where NameCollection='%s'", item))))
                        {
                            if (listBox2.Items.Count > 0)
                            {
                                if(db.HasUpdated(db.Query(db.PrepareQuery("DELETE FROM `videoinfo` where NameCollection='%s'", item))))
                                {                                   
                                }
                            }
                            Collection objtoremove = namesitemscollections.Find(Collection => Collection.Namecollection == item);
                            namesitemscollections.Remove(objtoremove);
                            listBox1.ItemsSource = null;
                            namesitemscollections.Clear();
                            listBox2.ItemsSource = null;
                            namesitemsvideos.Clear();
                            GetCollections();
                        }
                    }
                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message); }
            }
        }
        private void RemovePlaylist_Executed(object sendere, ExecutedRoutedEventArgs e)
        {
            if (listBox3.SelectedIndex > -1)
            {
                try
                {
                    string item = (listBox3.SelectedItem as Playlist).NamePlaylist;
                    MessageBoxResult result = MessageBox.Show("Do you want delete selected playlist?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        if(db.HasUpdated(db.Query(db.PrepareQuery("DELETE FROM `playlistinfo` where NamePlaylist='%s'", item))))
                        { }
                        if(listBox2.Items.Count > 0)
                        { listBox2.ItemsSource = null; namesitemsvideos.Clear(); }
                        listBox3.ItemsSource = null;
                        Playlist objtoremove = namesitemsplaylist.Find(Playlist => Playlist.NamePlaylist == item);
                        namesitemsplaylist.Remove(objtoremove);
                        listBox3.ItemsSource = namesitemsplaylist;

                    }

                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void ChangeImageColl_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Image Files (*.png, *.jpg, *jpeg)|*.png;*.jpg;*.jpeg";
                if (ofd.ShowDialog() == true)
                {
                    string collection = (listBox1.SelectedItem as Collection).Namecollection;
                    string newicon = ofd.FileName;
                    if (db.HasUpdated(db.Query(db.PrepareQuery("UPDATE collectioninfo SET IconPath='%s' WHERE NameCollection='%s'", newicon, collection))))
                    {
                        namesitemscollections.Clear();
                        listBox2.ItemsSource = null;
                        GetCollections();
                    }
                }
            }
        }
        private void ChangeNameColl_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                Chane_Name xx = new Chane_Name();
                xx.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                xx.Topmost = true;
                xx.Show();
            }
            else if (listBox3.SelectedIndex > -1)
            {
                Chane_Name xx = new Chane_Name();
                xx.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                xx.Topmost = true;
                xx.Show();
            }
        }
        private void RemoveVideos_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (listBox2.SelectedIndex > -1)
            {
                try
                {
                    string item = (listBox2.SelectedItem as Video).TitleNameVideo;
                    if (db.HasUpdated(db.Query(db.PrepareQuery("DELETE FROM `videoinfo` where Title='%s'", item))))
                    {
                        Video objtoremove = namesitemsvideos.Find(Video => Video.TitleNameVideo == item);
                        namesitemsvideos.Remove(objtoremove);
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Clear();
                        GetVideos();
                    }
                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message); }
            }
        }
        private void ResetCollections_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (db!=null && db.isConnected())
            {
                MessageBoxResult result = MessageBox.Show("Are you sure to reset database's table of collections?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    if (db.HasUpdated(db.Query("DELETE FROM `collectioninfo` WHERE 1")))
                    {
                        listBox1.ItemsSource = null;
                        namesitemscollections.Clear();
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Clear();
                    }
                }
            }
        }
        private void ResetPlaylists_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (db != null && db.isConnected())
            {
                MessageBoxResult result = MessageBox.Show("Are you sure to reset database's table of playlists?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    if (db.HasUpdated(db.Query("DELETE FROM `playlistinfo` WHERE 1")))
                    {
                        listBox3.ItemsSource = null;
                        namesitemsplaylist.Clear();
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Clear();
                    }
                }
            }
        }
        private void ResetVideos_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (db!=null && db.isConnected())
            {
                MessageBoxResult result = MessageBox.Show("Are you sure to reset database's table of videos?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    if (db.HasUpdated(db.Query("DELETE FROM `videoinfo` WHERE 1")))
                    {
                        listBox2.ItemsSource = null;
                        namesitemsvideos.Clear();
                    }
                }
            }
        }
        private void ResetConfiguration_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (File.Exists(xml))
            {
                MessageBoxResult result = MessageBox.Show("Are you sure to reset configuration?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    File.Delete(xml);
                }
            }
        }

        private void buttonVideo_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(boxVideo1.Text)) { MessageBox.Show("Any fields can be empty"); return; }
            else if (string.IsNullOrEmpty(boxVideo2.Text)) { MessageBox.Show("Any fields can be empty"); return; }
            else if (string.IsNullOrEmpty(boxVideo3.Text)) { MessageBox.Show("Any fields can be empty"); return; }

            if (listBox1.SelectedIndex > -1)
            {
                CreateVideo();
            }
            else
            {
                MessageBox.Show("Select a collection");
            }
        }

        private void buttonCollection_Click_1(object sender, RoutedEventArgs e)
        {
            string variable = boxCollection.Text;
            if (string.IsNullOrEmpty(variable))
            {
                MessageBox.Show("Field can not be empty.");
                return;
            }
            else if (variable == "Collection Name")
            {
                MessageBox.Show("Please insert a valid name.");
                return;
            }
            else
            {
                CreateCollections();
            }

        }

        private void configBox_Clear(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Foreground == Brushes.Black)
                return;

                tb.Text = string.Empty;
        }
        private void searchBox_Clear(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (searchbox.Text == "Search in...")
            {
                tb.Text = string.Empty;
            }
        }
        private void serverBox_Text(object sender, RoutedEventArgs e)
        {
            var defaultcolor = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFBFBFBF"));
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                if (File.Exists(Configuration.xmlPath))
                {
                    Configuration xml = new Configuration();
                    Conf DBConf = xml.ReadFile();
                    tb.Text = DBConf.HOST;
                }
                else 
                { 
                    tb.Text = "Insert server name";
                }
            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void dbBox_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                if (File.Exists(Configuration.xmlPath))
                {
                    Configuration xml = new Configuration();
                    Conf DBConf = xml.ReadFile();
                    tb.Text = DBConf.DBNAME;
                }
                else { tb.Text = "Insert database name"; }
            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void rootusBox_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                if (File.Exists(Configuration.xmlPath))
                {
                    Configuration xml = new Configuration();
                    Conf DBConf = xml.ReadFile();
                    tb.Text = DBConf.USER;
                }
                else { tb.Text = "Insert root username"; }
            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void rootpwBox_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                if (File.Exists(Configuration.xmlPath))
                {
                    Configuration xml = new Configuration();
                    Conf DBConf = xml.ReadFile();
                    tb.Text = DBConf.PASS;
                }
                else
                { tb.Text = "Insert root password"; }
            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void collectionBox_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Collection Name";

            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void searchbox_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Search in...";

            }
        }
        private void ButtonConfig_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Configuration xml = new Configuration();
                xml.SaveFile(serverBox.Text, roousBox.Text, roopwBox.Text, databaseBox.Text);
                Conf DBConf = xml.ReadFile();
                db = new Database(DBConf.HOST, DBConf.USER, DBConf.PASS, DBConf.DBNAME);
                GetCollections();
           
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }
        private void buttonPath_Click(object sender, RoutedEventArgs e)
        {

        }
        private void video1Box_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Band Name/Album";

            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void video2Box_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Title Song";

            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void video3Box_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Style Band";

            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }
        private void video4Box_Text(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Url/Uri Video";

            }
            else
            {
                tb.Foreground = Brushes.Black;
            }
        }


        private void IconCollection_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.png, *.jpg, *jpeg)|*.png;*.jpg;*.jpeg" ;
            if (ofd.ShowDialog() == true)
            {
                iconpathcollection = ofd.FileName;               
            }
        }

        private void ButtonSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchItemByKey();
        }
        private void SearchCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            SearchItemByKey();
        }
        private void SearchItemByKey()
        {
            List<Collection> searcheditem = new List<Collection>();
            List<Video> searcheditemvideo = new List<Video>();
            string comparestring = searchbox.Text;

            if (!string.IsNullOrEmpty(comparestring))
            {
                if (combosearch.Text == "Collections")
                {
                    bool found = false;
                    if (namesitemscollections.Count > -1)
                    {                       
                        foreach (Collection xx in namesitemscollections.ToList())
                        {
                            string aaa = xx.Namecollection;
                            if (aaa.Contains(comparestring))
                            {
                                found = true;
                                searcheditem.Add(xx);
                            }
                        }
                        if (found == true)
                        {
                            listBox1.ItemsSource = null;
                            namesitemscollections.Clear();
                            listBox1.ItemsSource = searcheditem;
                        }
                        else if (found == false)
                        {
                            MessageBox.Show("Item not found");
                        } 
                    }
                }
                 else if (combosearch.Text == "Videos")
                {
                    bool found = false;
                    if (namesitemsvideos.Count > -1)
                    {
                        foreach (Video xx in namesitemsvideos.ToList())
                        {
                            string aaa = xx.TitleNameVideo;
                            if (aaa.Contains(comparestring))
                            {
                                found = true;
                                searcheditemvideo.Add(xx);
                            }
                        }
                        if (found == true)
                        {
                            listBox2.ItemsSource = null;
                            namesitemsvideos.Clear();
                            listBox2.ItemsSource = searcheditemvideo;
                        }
                        else if (found == false)
                        {
                            MessageBox.Show("Item not found");
                        }
                    }
                }
            }
        }
        private void DeleteSearch_Click(object sender, RoutedEventArgs e)
        {
            string gg = searchbox.Text;
            if (!string.IsNullOrEmpty(gg) && !gg.Contains("Search"))
            {
                searchbox.Text = string.Empty;
                listBox1.ItemsSource = null;
                namesitemscollections.Clear();
                GetCollections();
                listBox2.ItemsSource = null;
                namesitemsvideos.Clear();
                GetVideos();
            }
        }

        private void IconVideo_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.png, *.jpg, *jpeg)|*.png;*.jpg;*.jpeg";
            if (ofd.ShowDialog() == true)
            {
                iconpathvideo = ofd.FileName;
            }
        }

        private void BackupButton_Click_1(object sender, RoutedEventArgs e)
        {
            ExecuteBackupNow();
        }

        private void RestoreButton_Click_1(object sender, RoutedEventArgs e)
        {
            ExecuteRestoreNow();
        }

        private void PlayAudioButton_Click(object sender, RoutedEventArgs e)
        {                    
            if(listBox2.SelectedIndex > -1 )
            {               
                urltoplay = (listBox2.SelectedItem as Video).UrlVideo;
                if(urltoplay != null)
                {
                    VlcFound._VlcFound.axVLCPlugin21.playlist.add(urltoplay);
                    VlcFound._VlcFound.axVLCPlugin21.playlist.play();
                        // string[] options = { "--audio-visual=visual","--effect-list=spectrometer" };
  
                }
            }
            else if (listBox3.SelectedIndex > -1 && listBox2.SelectedIndex == -1)
            {
                if (listBox2.Items.Count > 0)
                {
                    VlcFound._VlcFound.axVLCPlugin21.playlist.items.clear();
                    foreach(Video xx in listBox2.Items)
                    {
                        VlcFound._VlcFound.axVLCPlugin21.playlist.add(xx.UrlVideo);
                    }
                    VlcFound._VlcFound.axVLCPlugin21.playlist.play();
                }
            }
        }

        private void PauseAudioButton_Click(object sender, RoutedEventArgs e)
        {
            if (VlcFound._VlcFound.axVLCPlugin21.playlist.isPlaying)
            {
                PositionNewValue = VlcFound._VlcFound.axVLCPlugin21.input.Position;
                PositionChanged = true;
                VlcFound._VlcFound.axVLCPlugin21.playlist.pause();
            }         
        }
        private void Skipavanti_Click(object sender, RoutedEventArgs e)
        {
            if (VlcFound._VlcFound.axVLCPlugin21.playlist.isPlaying)
            {
                VlcFound._VlcFound.axVLCPlugin21.input.Position += 0.015;
            }
        }
        private void Skipindietro_Click(object sender, RoutedEventArgs e)
        {
            if (VlcFound._VlcFound.axVLCPlugin21.playlist.isPlaying)
            {
                VlcFound._VlcFound.axVLCPlugin21.input.Position -= 0.015;
            }
        }
        private void ReplayAudioButton_Click(object sender, RoutedEventArgs e)
        {
            VlcFound._VlcFound.axVLCPlugin21.playlist.stop();
            VlcFound._VlcFound.axVLCPlugin21.playlist.play();
        }

        private void StopAudioButton_Click(object sender, RoutedEventArgs e)
        {
            if (VlcFound._VlcFound.axVLCPlugin21.playlist.isPlaying)
            {
                VlcFound._VlcFound.axVLCPlugin21.playlist.stop();
                VlcFound._VlcFound.axVLCPlugin21.playlist.items.clear();
            }
            
        }

        private void PlaylistButton_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 playlistwindow = new Window1();
            playlistwindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            playlistwindow.Topmost = true;
            playlistwindow.Show();

        }

        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {
            InfoWindow infowindow = new InfoWindow();
            infowindow.Topmost = true;
            infowindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            if(btnenabled == true)
            {
                infowindow.dwnloadbtn.IsEnabled = true;
            }
            infowindow.Show();         
        }

        public void GetDetails()
        {
            if (listBox2.SelectedIndex > -1)
            {
                ResetRating();

                string urimage = (listBox2.SelectedItem as Video).IconPathvideo;
                DetNameAlbum.Text = (listBox2.SelectedItem as Video).BandNameVideo;
                DetNameSong.Text = (listBox2.SelectedItem as Video).TitleNameVideo;
                DetNameStyle.Text = (listBox2.SelectedItem as Video).StyleNameVideo;
                DetUrl.Text = (listBox2.SelectedItem as Video).UrlVideo;

                DetPathIcon.Text = urimage;

                int votevideo = Convert.ToInt16((listBox2.SelectedItem as Video).VoteVideo);

                CurrentRate(votevideo);

                if (File.Exists(urimage))
                {
                    ImageSource xx = new BitmapImage(new Uri(urimage));
                    DetIcon.Source = xx;
                }
                else
                {
                    DetIcon.Source = null;
                }
            }
        }
        private void listBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
                GetDetails();         
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if((int)Slider.Value > 0)
            {
                SavedCurrentVolume = (int)Slider.Value;
            }
        }

        private void CancelDetBut_Click(object sender, RoutedEventArgs e)
        {
            GetDetails();
        }

        private void SaveDetBut_Click(object sender, RoutedEventArgs e)
        {
            int index = listBox2.SelectedIndex;
            if (listBox2.SelectedIndex > -1)
            {
                UpdateVideo();
            }
            listBox2.SelectedIndex = index;
        }
        private void CancelDetails()
        {
            DetNameAlbum.Text = null;
            DetNameSong.Text = null;
            DetNameStyle.Text = null;
            DetUrl.Text = null;
            ResetRating();
            DetPathIcon.Text = null;
            DetIcon.Source = null;
        }

        private void MuteVolButton_Click_1(object sender, RoutedEventArgs e)
        {
            if(MuteVolButton.Content == FindResource("Play"))
            {
                Slider.IsEnabled = true;
                Slider.Value = SavedCurrentVolume;
                MuteVolButton.Content = FindResource("Stop");
            }
            else
            {
                Slider.IsEnabled = false;
                Slider.Value = 0;
                MuteVolButton.Content = FindResource("Play");
            }

        }

        private void SliderTime_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (VlcFound._VlcFound.axVLCPlugin21.playlist.isPlaying)
            {
                VlcFound._VlcFound.axVLCPlugin21.input.Position = SliderTime.Value / 100;
                //MessageBox.Show((SliderTime.Value / 100).ToString());
            }
        }

        private void DetButtonPathicon_Click(object sender, RoutedEventArgs e)
        {
            if (listBox2.SelectedIndex > -1)
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Image Files (*.png, *.jpg, *jpeg)|*.png;*.jpg;*.jpeg";
                if (ofd.ShowDialog() == true)
                {
                    DetPathIcon.Text = ofd.FileName;
                    if (File.Exists(DetPathIcon.Text))
                    {
                        ImageSource xx = new BitmapImage(new Uri(DetPathIcon.Text));
                        DetIcon.Source = xx;
                    }
                    else
                    {
                        DetIcon.Source = null;
                    }
                }
            }
        }
        private void Rate(object sender, MouseButtonEventArgs e)
        {
            if (listBox2.SelectedIndex > -1)
            {
                for (int i = 0; i < elem.Count(); i++)
                {
                    Image restore = new Image();
                    restore = (Image)elem[i];
                    ImageSource xx = new BitmapImage(new Uri(@"pack://application:,,,/MediaPlaylister;component/Resources/Stellavuota.png",
                    UriKind.RelativeOrAbsolute));
                    restore.Source = xx;
                }
                Image px = new Image();
                px = (Image)sender;
                for (int i = 0; i < elem.Count(); i++)
                {
                    Image check = new Image();
                    check = (Image)elem[i];
                    if (px.Name == check.Name)
                    {
                        curRate = i + 1;
                        for (int j = 0; j <= i; j++)
                        {
                            check = (Image)elem[j];
                            ImageSource aa = new BitmapImage(new Uri(@"pack://application:,,,/MediaPlaylister;component/Resources/Stellapiena.png",
                            UriKind.RelativeOrAbsolute));
                            check.Source = aa;
                        }
                    }
                }
            }
        }
        public void CurrentRate( int voteint)
        {
            if (listBox2.SelectedIndex > -1)
            {
                for (int i = 0; i < voteint; i++)
                {
                    Image check = new Image();
                    check = (Image)elem[i];
                    curRate = i+1;
                    for (int j = 0; j <= i; j++)
                    {
                        check = (Image)elem[j];
                        ImageSource aa = new BitmapImage(new Uri(@"pack://application:,,,/MediaPlaylister;component/Resources/Stellapiena.png",
                        UriKind.RelativeOrAbsolute));
                        check.Source = aa;
                    }                   
                }
            }
        }
        public void ResetRating()
        {
            for (int i = 0; i < elem.Count(); i++)
            {
                Image check = new Image();
                check = (Image)elem[i];
                curRate = i + 1;
                for (int j = 0; j <= i; j++)
                {
                    check = (Image)elem[j];
                    ImageSource aa = new BitmapImage(new Uri(@"pack://application:,,,/MediaPlaylister;component/Resources/Stellavuota.png",
                    UriKind.RelativeOrAbsolute));
                    check.Source = aa;
                }
            }
        }

        private void listBox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GetVideosPlaylist();
            //listBox2.ItemsSource = null;
           // listBox2.ItemsSource = videosforplaylist;
        }

        private void TabItem_GotFocus(object sender, RoutedEventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                listBox1.SelectedIndex = -1;

                if (listBox2.Items.Count > 0)
                {
                    namesitemsvideos.Clear();
                    listBox2.ItemsSource = null;
                }
            }
        }

        private void TabItem_GotFocus_1(object sender, RoutedEventArgs e)
        {
            if (listBox3.SelectedIndex > -1)
            {
                listBox3.SelectedIndex = -1;

                if (listBox2.Items.Count > 0)
                {
                    namesitemsvideos.Clear();
                    listBox2.ItemsSource = null;
                }
            }
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            string namefileupdater = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\PlaylisterUpdater.exe"; 
            if(File.Exists(namefileupdater))
            {
                File.Delete(namefileupdater);
            }
            CheckVersion();


        }


    }
}
