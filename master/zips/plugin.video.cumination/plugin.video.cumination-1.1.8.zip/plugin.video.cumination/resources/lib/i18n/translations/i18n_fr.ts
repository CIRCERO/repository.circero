<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Premier</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Troisième</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Langue : %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Français</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblique</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Deuxième</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isométrique</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspective</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Exemple d&apos;internationalisation</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
